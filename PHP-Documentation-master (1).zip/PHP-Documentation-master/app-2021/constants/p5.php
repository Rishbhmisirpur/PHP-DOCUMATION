<?php

error_reporting(E_USER_DEPRECATED);
//error_reporting(E_DEPRECATED);

//wap in php to make non-case-sensitive user-defined Constants

define('gravity',10,true);
echo gravity;

echo PHP_EOL;

echo GRAVITY; 
echo PHP_EOL;

echo Gravity; 
echo PHP_EOL;

echo GrAviTy; 





