<?php

//wap in php to show the concept of floor concept.

$no1 = readline('Enter any float value:');
echo "The floating point value = $no1 ";
echo PHP_EOL;

$no2 = floor($no1);

echo "The floor value = $no2 ";