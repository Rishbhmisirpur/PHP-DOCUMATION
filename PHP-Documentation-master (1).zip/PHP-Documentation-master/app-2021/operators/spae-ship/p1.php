<?php

//wap in php to show spaceship Operator

var_dump(5==5);
var_dump(5<=>5);

var_dump(6>5);
var_dump(6<=>5);

var_dump(4<5);
var_dump(4<=>5);
