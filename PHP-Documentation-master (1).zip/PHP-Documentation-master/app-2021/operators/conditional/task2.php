<?php


//wap in php to find odd and even

$a=readline('Enter the a value:');
$output = ($a%2)?'odd':'even';
echo $output;





