<?php


//wap in php to find modulas

$a=readline('Enter the a value:');
$n = ($a > 0)?$a:-($a);

echo "The |$a| is = $n ";





