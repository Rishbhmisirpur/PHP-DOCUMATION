<?php

//wap in php to show logical Operators And

$x=readline('Enter the x value in Range:');

var_dump($x!=10);
var_dump(!(!($x<10) && !($x>10))); //De-morgan Rules

