<?php

//wap in php to find odd and even using single if

$output='Odd';
$n = readline('Enter the Number:');

if($n%2==0){
	$output='Even';
}

echo $output;








