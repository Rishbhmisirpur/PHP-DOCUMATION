<?php

//wap in php to show, Empty class 

class Test{



}


