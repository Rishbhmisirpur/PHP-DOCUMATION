<?php

//This is Setting file

################ All Constants ##########################
define('HOST','localhost:3308');
define('USER','root');
define('PASSWORD','');
define('DBNAME','app2021');
define('DB_CHECK',false);

################ All Constants ##########################

return [
	
	'db:config'=>[
		
		'host'=>'145.14.153.101',
		'user'=>'u323470395_vsfIs',
		'password'=>'5~+Fs@M1oK',
		'dbname'=>'u323470395_3VqkN',
	]

];
