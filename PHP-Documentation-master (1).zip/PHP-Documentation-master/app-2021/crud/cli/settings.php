<?php

//This is Setting file

################ All Constants ##########################
define('HOST','localhost:3308');
define('USER','root');
define('PASSWORD','');
define('DBNAME','app2021');

################ All Constants ##########################

return [
	
	'db:config'=>[
		
		'host'=>'localhost:3308',
		'user'=>'root',
		'password'=>'',
		'dbname'=>'app2021',
	]

];
