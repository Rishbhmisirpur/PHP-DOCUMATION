<?php

//wap in php to say Hello 100 times.
for($i=1;$i<=100;print("Hello $i \n"),$i++);
