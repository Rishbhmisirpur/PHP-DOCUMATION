<?php

//wap in php to show variables

$y; //valid
$x=10;
echo $x; //Notice Error : Undefined varaible $x;

