<?php
// wap in php to find sum using readline()


$no1 = readline('Enter no 1:');
$no2 = readline('Enter no 2:');

$sum = $no1+$no2;
printf("The sum is = %d ",$sum);


?>