<?php

//wap in php to show how a $variabl can hold a value


$arr = array(10,20,30,40,'red','green');
echo $arr; //Array to string conversion

echo PHP_EOL;
print_r($arr); //r --> resource
echo PHP_EOL;
var_dump($arr);
echo PHP_EOL;
var_export($arr);




