<?php

$conn = mysqli_connect('localhost:3308','root','','');
var_dump($conn); #Object ---> Resource
