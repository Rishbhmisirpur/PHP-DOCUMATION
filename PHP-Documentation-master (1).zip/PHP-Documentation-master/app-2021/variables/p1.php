<?php

// Making a numerical varibles

$x=10; // variable declaration + Intialisation

echo $x; //echo predefined language construct 
echo PHP_EOL; //predefined constant
echo getType($x); //predefined function


?>

