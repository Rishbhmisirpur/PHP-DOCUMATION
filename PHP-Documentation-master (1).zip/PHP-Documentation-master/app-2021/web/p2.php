<!Doctype html>
<html lang="US-en">
	<head>
	</head>
	<body>
		<h1>HTML FORM</h1>
		<hr/>
		
		<form action="handle-p2.php" method="GET">
		
		<p>
			Enter the Name: <input type="text" id="name" name="name" />
		</p>
		
		<input type="submit" id="submit" name="submit" />
		
		</form>
		
	</body>
</html>