<?php  

//wap in php to say hello chacha

echo "Hello Chacha";



?>