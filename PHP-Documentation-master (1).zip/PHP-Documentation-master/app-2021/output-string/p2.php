<?php

//wap in to show possible no of cases in output string

echo "Hy Mohan`s Friend ";
echo PHP_EOL;
echo '"King is King" says -Robert Clibert ';
echo PHP_EOL;
echo "My Favourite Herione is 'Katreena'. ";
echo PHP_EOL;

#echo `HY`"; //Invalid

echo PHP_EOL;
echo 'SELECT * FROM `student`;';
echo PHP_EOL;
echo "SELECT * FROM `student` WHERE ID='1';";