<?php

// wap in php to show '' inside '' Qoutes is Invalid;

echo 'How are You!!'; //single Qoute
echo PHP_EOL; 
echo "Katreena"; //single Qoute

echo PHP_EOL; 
echo 'Hy, Mr Papa`s Friends'; //backtick
echo PHP_EOL; 

#echo 'Hy, Mr Papa's Friends'; //parseError
echo PHP_EOL; 
echo "This is Single Qoute's inside double";
echo PHP_EOL; 
echo "This is Single back tick Qoute`s inside double"; 

echo PHP_EOL; 
#echo "Awnish Says "Bolooon" ";

?>