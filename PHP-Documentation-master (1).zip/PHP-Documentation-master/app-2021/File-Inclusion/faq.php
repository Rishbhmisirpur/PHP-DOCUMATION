<?php include __DIR__.'/layouts/header.php'; ?>

<H1>This is FAQ Page</H1>

<?php include __DIR__.'/layouts/footer.php'; ?>