<ul>
		<li><a href="home.php">Home</a></li>
		<li><a href="contact.php">Contact</a></li>
		<li><a href="faq.php">Faq</a></li>
		<li><a href="about.php">About</a></li>
		<li><a href="#">Services</a></li>
</ul>