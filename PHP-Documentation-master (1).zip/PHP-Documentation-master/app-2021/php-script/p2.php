<?php

//wap in php to Hybrid PHP file


echo 'This part is from Hybrid PHP File';
echo PHP_EOL;
echo '<h1>This is Heading from HTML CODE</h1>';

//here closing mendatory.
?>

<h1>This is Heading from HTML CODE</h1>
<script>window.alert('Hy from Js');</script>