<?php

//This is a core php file

include 'p3.inc.php';

echo "The value of x from p3.inc file $x";



