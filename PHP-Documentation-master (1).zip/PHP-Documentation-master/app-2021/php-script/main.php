<?php

define('APP_KEY','awnishkr123');

include 'external.inc.php';

